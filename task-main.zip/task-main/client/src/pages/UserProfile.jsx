import React from "react";
import Index from "../Components/UserProfile/Index";

const UserProfile = () => {
  return (
    <>
      <Index />
    </>
  );
};

export default UserProfile;
