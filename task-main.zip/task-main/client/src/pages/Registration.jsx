import React from "react";
import Signup from "../Components/accounts/Signup";

const Registration = () => {
  return <Signup />;
};

export default Registration;
