import React from "react";
import Index from "../Components/PagesCompoents/Categories/Index";

const Category = () => {
  return <Index />;
};

export default Category;
