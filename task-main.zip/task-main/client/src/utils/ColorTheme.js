export const color1 = "black";
export const color2 = "white";
export const color3 = "#0F172A";
export const color4 = "#192232";
export const color5 = "gray";
export const redColor = "#CD292E";
