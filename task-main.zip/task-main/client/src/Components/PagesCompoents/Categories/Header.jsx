import React from "react";

const Header = () => {
  return (
    <div className="w-full   py-2 relative">
      <img
        src="https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/15e62b31468037.565233cb92a4f.jpg"
        className=" w-[100%] h-[350px]"
        alt=""
      />
    </div>
  );
};

export default Header;
