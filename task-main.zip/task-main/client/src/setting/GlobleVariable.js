// export const ApiURL = "http://192.168.1.166:4000/api";
export const ApiURL = "http://192.168.1.168:4000/api";
export const ApiMediaURL = "http://192.168.1.165:4000/uploads/";
// ========================================= live
// export const ApiURL = "http://44.211.254.82:4000/api";
// export const ApiMediaURL = "http://44.211.254.82:4000/uploads/";
